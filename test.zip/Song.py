import json
class Song:
    def __init__(self, songName, artistName, lyric):
        self.songName = songName
        self.artistName = artistName
        self.lyric = lyric

    def getSongName(self):
        return self.songName
    def getArtistName(self):
        return self.artistName
    def getLyric(self):
        return self.lyric

    def storeToFileSystem(self, filename, append):
        file = open(filename, ("w+","a+")[append])
        json.dump(self.__dict__, file)
        file.close()

    def write(self):
        file = open(self.songName, "w+")
        file.write(self.getLyric())
        file.close()
