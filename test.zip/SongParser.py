from bs4 import BeautifulSoup
import requests
from hanziconv import HanziConv
from Song import Song

class SongParser:
    def __init__(self, url):
        self.url = url
        res = requests.get(url, timeout=2)
        self.page = BeautifulSoup(res.text,"html.parser")
        text = self.page.find(id="fsZx1")
        texts = text.prettify().split("\n")
        # store processed and filtered lyric
        filtered = []
        for s in texts:
            s =s.strip()
            if(s == "<ol>"):
                break
            if not s.startswith("<") and s.find("：") == -1 and s.find("※") == -1 and not s.startswith("["):
                filtered.append(s)

        self.artistName = HanziConv.toSimplified(filtered.pop(0))
        self.songName = HanziConv.toSimplified(filtered.pop(0))
        s = ""
        for t in filtered:
            s = s + t + "\n"
        # return a string representation of the lyric. each line is separated by
        # \n
        self.lyric = HanziConv.toSimplified(s)
        self.relatedPages = self.relatedPages()

    def createSong(self):
        return Song(self.songName, self.artistName, self.lyric)

    def getRelatedPages(self):
        return self.relatedPages

    def relatedPages(self):
        resourcePath = "/" + self.url.split("//")[1].split("/")[1]
        baseUrl = self.url.split("//")[0] + "//" + self.url.split("//")[1].split("/")[0]

        b = self.page
        temp = b.find_all('a')

        pages = []
        for s in temp:
            if s.prettify().find("href=\"/cny") != -1 and s.prettify().find("9999.htm") == -1 and s.get("href") != resourcePath:
                pages.append(baseUrl + s.get("href"))
        return pages
