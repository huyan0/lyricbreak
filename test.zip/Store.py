class StoreObj:
    def __init__(self, dataSoure):
        self.dataSource = dataSoure

    def store(self, song):
        
