from SongParser import SongParser

def crawlSongs(startUrl, generation):
    if generation != 0:
        p1 = SongParser(startUrl)
        s = p1.createSong()
        s.storeToFileSystem("lyrics/" + s.getSongName() + ".json", False)
        s.write()
        for p in p1.getRelatedPages():
            crawlSongs(p, generation - 1)
