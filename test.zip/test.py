import crawler

# source must be in simplified chinese
crawler.crawlSongs("https://mojim.com/cny216077x4x1.htm",1)
